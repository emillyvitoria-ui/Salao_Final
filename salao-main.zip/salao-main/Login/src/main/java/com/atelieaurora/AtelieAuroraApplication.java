
package com.atelieaurora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtelieAuroraApplication {

    public static void main(String[] args) {

        SpringApplication.run(AtelieAuroraApplication.class, args);

    }
}
