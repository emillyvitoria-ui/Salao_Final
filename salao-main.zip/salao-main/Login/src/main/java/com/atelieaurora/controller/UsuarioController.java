package com.atelieaurora.controller;


import com.atelieaurora.dto.CadastroDTO;
import com.atelieaurora.dto.LoginDTO;
import com.atelieaurora.entidade.Usuario;
import com.atelieaurora.service.UsuarioService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    // CADASTRO
    @PostMapping("/cadastro")
    public ResponseEntity<?> cadastrar(
            @Valid @RequestBody CadastroDTO dados) {

        Usuario usuario = service.cadastrar(dados);

        return ResponseEntity.ok(resposta(usuario));
    }

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(
            @Valid @RequestBody LoginDTO dados,
            HttpSession sessao) {

        Usuario usuario = service.login(
                dados.email(),
                dados.senha()
        );

        sessao.setAttribute("usuarioId", usuario.getId());

        return ResponseEntity.ok(resposta(usuario));
    }

    // CONSULTAR USUÁRIO LOGADO
    @GetMapping("/me")
    public ResponseEntity<?> usuarioAtual(HttpSession sessao) {

        Object id = sessao.getAttribute("usuarioId");

        if (id == null) {
            return ResponseEntity.status(401).build();
        }

        return ResponseEntity.ok(
                Map.of("id", id)
        );
    }

    // SAIR DA CONTA
    @PostMapping("/sair")
    public ResponseEntity<?> sair(HttpSession sessao) {

        sessao.invalidate();

        return ResponseEntity.ok(
                Map.of("mensagem", "Você saiu da sua conta.")
        );
    }

    // Informações que podem voltar para o HTML
    private Map<String, Object> resposta(Usuario usuario) {

        Map<String, Object> dados = new HashMap<>();

        dados.put("id", usuario.getId());
        dados.put("nome", usuario.getNome());
        dados.put("email", usuario.getEmail());
        dados.put("telefone", usuario.getTelefone());
        dados.put("pontos", usuario.getPontos());

        return dados;
    }
}