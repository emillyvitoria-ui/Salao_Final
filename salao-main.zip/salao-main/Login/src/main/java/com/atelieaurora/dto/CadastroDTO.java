package com.atelieaurora.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CadastroDTO(

        @NotBlank(message = "Informe seu nome.")
        String nome,

        @NotBlank(message = "Informe seu e-mail.")
        @Email(message = "E-mail inválido.")
        String email,

        @NotBlank(message = "Informe seu telefone.")
        String telefone,

        @NotBlank(message = "Informe sua senha.")
        @Size(min = 6, message = "A senha precisa ter pelo menos 6 caracteres.")
        String senha

) {
}