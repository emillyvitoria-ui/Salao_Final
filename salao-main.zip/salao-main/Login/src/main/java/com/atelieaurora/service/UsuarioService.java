package com.atelieaurora.service;

import com.atelieaurora.dto.CadastroDTO;
import com.atelieaurora.entidade.Usuario;
import com.atelieaurora.repository.UsuarioRepository;

import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UsuarioService {

    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(
            UsuarioRepository repository,
            PasswordEncoder passwordEncoder) {

        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    // CADASTRAR USUÁRIO
    public Usuario cadastrar(CadastroDTO dados) {

        String email = dados.email().trim().toLowerCase();

        if (repository.existsByEmail(email)) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Este e-mail já está cadastrado."
            );
        }

        Usuario usuario = new Usuario();

        usuario.setNome(dados.nome().trim());
        usuario.setEmail(email);
        usuario.setTelefone(dados.telefone());

        // Criptografa a senha antes de salvar
        usuario.setSenha(
                passwordEncoder.encode(dados.senha())
        );

        usuario.setPontos(50);

        return repository.save(usuario);
    }

    // VERIFICAR LOGIN
    public Usuario login(String email, String senha) {

        Usuario usuario = repository
                .findByEmail(email.trim().toLowerCase())
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.UNAUTHORIZED,
                        "E-mail ou senha incorretos."
                ));

        // Compara a senha com o hash do banco
        if (!passwordEncoder.matches(senha, usuario.getSenha())) {

            throw new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED,
                    "E-mail ou senha incorretos."
            );
        }

        return usuario;
    }
}