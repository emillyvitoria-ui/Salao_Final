/* ==========================================================
   app.js - funções compartilhadas por todas as páginas
   ========================================================== */

/* ---------- Atalho para document.querySelector ---------- */
const $ = (seletor, raiz = document) => raiz.querySelector(seletor);


/* ---------- Armazenamento (localStorage) ---------- */
function ler(chave, padrao) {
  try {
    return JSON.parse(localStorage.getItem(chave)) ?? padrao;
  } catch {
    return padrao;
  }
}

const usuarios = () => ler('salao_usuarios', []);

const salvarUsuarios = (lista) =>
  localStorage.setItem('salao_usuarios', JSON.stringify(lista));


/* ---------- Sessão (quem está logada) ---------- */
// "Manter conectada" usa localStorage; senão, sessionStorage
const emailSessao = () =>
  localStorage.getItem('salao_sessao') || sessionStorage.getItem('salao_sessao');

const usuarioAtual = () =>
  usuarios().find((u) => u.email === emailSessao()) || null;

function entrar(email, lembrar) {
  (lembrar ? localStorage : sessionStorage).setItem('salao_sessao', email);
  location.href = 'painel.html';
}

function sair() {
  localStorage.removeItem('salao_sessao');
  sessionStorage.removeItem('salao_sessao');
  location.href = 'login.html';
}


/* ---------- Utilidades ---------- */
// Codificação simples (apenas para demonstração, não é segurança real)
const codificar = (texto) => btoa(unescape(encodeURIComponent(texto)));

const emailValido = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);


/* ---------- Mensagem temporária (toast) ---------- */
function toast(mensagem) {
  let el = $('.toast');

  if (!el) {
    el = document.createElement('div');
    el.className = 'toast';
    el.setAttribute('role', 'status');
    document.body.append(el);
  }

  el.textContent = mensagem;
  el.classList.add('on');
  setTimeout(() => el.classList.remove('on'), 2600);
}


/* ---------- Botão "Mostrar/Ocultar" senha ---------- */
document.addEventListener('click', (e) => {
  const botao = e.target.closest('[data-olho]');
  if (!botao) return;

  const campo = botao.previousElementSibling;
  campo.type = campo.type === 'password' ? 'text' : 'password';
  botao.textContent = campo.type === 'password' ? 'Mostrar' : 'Ocultar';
});


/* ---------- Máscara de telefone: (00) 00000-0000 ---------- */
function mascaraTel(input) {
  input.addEventListener('input', () => {
    let v = input.value.replace(/\D/g, '').slice(0, 11);
    v = v.replace(/^(\d{2})(\d)/, '($1) $2')
         .replace(/(\d{5})(\d{1,4})$/, '$1-$2');
    input.value = v;
  });
}