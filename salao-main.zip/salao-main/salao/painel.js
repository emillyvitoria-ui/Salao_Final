/* ==========================================================
   painel.js - lógica do painel da cliente
   ========================================================== */

/* ---------- Proteção: só entra quem estiver logada ---------- */
let me = usuarioAtual();
if (!me) location.href = 'login.html';


/* ==========================================================
   DADOS (edite aqui para mudar serviços, equipe e horários)
   ========================================================== */
const SERVICOS = [
  { id: 1, n: 'Corte feminino',        p: 90,  d: 60  },
  { id: 2, n: 'Corte masculino',       p: 50,  d: 30  },
  { id: 3, n: 'Escova modelada',       p: 60,  d: 45  },
  { id: 4, n: 'Coloração',             p: 180, d: 120 },
  { id: 5, n: 'Mechas e luzes',        p: 320, d: 180 },
  { id: 6, n: 'Manicure e pedicure',   p: 75,  d: 90  },
  { id: 7, n: 'Design de sobrancelha', p: 45,  d: 30  },
  { id: 8, n: 'Limpeza de pele',       p: 140, d: 60  },
  { id: 9, n: 'Hidratação profunda',   p: 85,  d: 45  },
];  // n = nome, p = preço, d = duração em minutos

const PROFISSIONAIS = [
  { id: 1, n: 'Helena Duarte', e: 'Cabelo e coloração'   },
  { id: 2, n: 'Marcos Vieira', e: 'Cortes e barba'       },
  { id: 3, n: 'Lívia Moreira', e: 'Unhas e sobrancelhas' },
  { id: 4, n: 'Bianca Rocha',  e: 'Estética facial'      },
];  // n = nome, e = especialidade

const HORARIOS = ['09:00', '10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'];

const PONTOS_PARA_DESCONTO = 200;


/* ==========================================================
   FUNÇÕES AUXILIARES
   ========================================================== */
const formatarPreco = (v) => 'R$ ' + v.toFixed(2).replace('.', ',');
const formatarData  = (d) => d.split('-').reverse().join('/');   // 2026-11-03 -> 03/11/2026
const hojeISO       = ()  => new Date().toISOString().slice(0, 10);

const buscarServico = (id) => SERVICOS.find((s) => s.id == id);
const buscarProf    = (id) => PROFISSIONAIS.find((p) => p.id == id);

// Escolha atual na tela de agendamento
let escolha = { servico: null, prof: null, hora: null };

// Grava as alterações da usuária atual no localStorage
function salvar() {
  const lista = usuarios();
  lista[lista.findIndex((u) => u.email === me.email)] = me;
  salvarUsuarios(lista);
}

// Ordena agendamentos por data e hora
const ordenar = (lista) =>
  [...lista].sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));


/* ==========================================================
   NAVEGAÇÃO ENTRE ABAS
   ========================================================== */
function irPara(id) {
  document.querySelectorAll('section').forEach((s) =>
    s.classList.toggle('ativo', s.id === id)
  );
  document.querySelectorAll('#nav button').forEach((b) =>
    b.classList.toggle('ativo', b.dataset.s === id)
  );

  if (id === 'meus') desenharLista();
  if (id === 'inicio') desenharInicio();
  scrollTo(0, 0);
}

$('#nav').addEventListener('click', (e) => {
  if (e.target.dataset.s) irPara(e.target.dataset.s);
});

$('#irAg').onclick = () => irPara('agendar');


/* ==========================================================
   ABA: INÍCIO
   ========================================================== */
function desenharInicio() {
  $('#ola').textContent = 'Olá, ' + me.nome.split(' ')[0] + '!';

  // Próximo horário (a partir de hoje)
  const proximo = ordenar(me.agendamentos).find((a) => a.data >= hojeISO());

  $('#prox').textContent = proximo
    ? `${buscarServico(proximo.s).n} com ${buscarProf(proximo.p).n}, dia ${formatarData(proximo.data)} às ${proximo.hora}.`
    : 'Você ainda não tem horários marcados.';

  // Programa fidelidade
  const progresso = me.pontos % PONTOS_PARA_DESCONTO;
  $('#pts').textContent =
    `${me.pontos} pontos. Faltam ${PONTOS_PARA_DESCONTO - progresso} para ganhar 15% de desconto.`;
  $('#barra').style.width = (progresso / PONTOS_PARA_DESCONTO) * 100 + '%';
}


/* ==========================================================
   ABA: AGENDAR
   ========================================================== */

// Cria uma grade de cartões clicáveis (serviços ou profissionais)
function desenharCartoes(elemento, itens, chave, conteudo) {
  elemento.innerHTML = itens
    .map((item) => `
      <button type="button" class="item ${escolha[chave] === item.id ? 'sel' : ''}" data-id="${item.id}">
        ${conteudo(item)}
      </button>`)
    .join('');

  elemento.onclick = (e) => {
    const cartao = e.target.closest('.item');
    if (!cartao) return;

    escolha[chave] = +cartao.dataset.id;
    escolha.hora = null;
    desenharAgendar();
  };
}

// Horários já ocupados para a profissional e a data escolhidas
function horariosOcupados() {
  return usuarios()
    .flatMap((u) => u.agendamentos)
    .filter((a) => a.p === escolha.prof && a.data === $('#data').value)
    .map((a) => a.hora);
}

function desenharAgendar() {
  desenharCartoes($('#gServ'), SERVICOS, 'servico', (s) => `
    <h3>${s.n}</h3>
    <small>${s.d} min</small>
    <div class="preco">${formatarPreco(s.p)}</div>`);

  desenharCartoes($('#gProf'), PROFISSIONAIS, 'prof', (p) => `
    <h3>${p.n}</h3>
    <small>${p.e}</small>`);

  // Horários disponíveis
  const data = $('#data').value;
  const ocupados = data && escolha.prof ? horariosOcupados() : [];

  $('#slots').innerHTML = data && escolha.prof
    ? HORARIOS.map((h) => `
        <button type="button" class="slot ${escolha.hora === h ? 'sel' : ''}" ${ocupados.includes(h) ? 'disabled' : ''}>
          ${h}
        </button>`).join('')
    : '<span class="vazio">Escolha a profissional e a data para ver os horários.</span>';

  $('#slots').onclick = (e) => {
    if (e.target.classList.contains('slot')) {
      escolha.hora = e.target.textContent.trim();
      desenharAgendar();
    }
  };

  // Resumo do pedido
  const servico = buscarServico(escolha.servico);
  $('#resumo').textContent = servico && escolha.prof && data && escolha.hora
    ? `${servico.n}, ${formatarData(data)} às ${escolha.hora}. Total: ${formatarPreco(servico.p)}`
    : '';
}

// Data mínima = hoje; domingos são bloqueados
$('#data').min = hojeISO();
$('#data').addEventListener('change', (e) => {
  const diaDaSemana = new Date(e.target.value + 'T12:00').getDay();

  if (diaDaSemana === 0) {
    toast('Fechamos aos domingos. Escolha outro dia.');
    e.target.value = '';
  }

  escolha.hora = null;
  desenharAgendar();
});

// Confirmar agendamento
$('#confirmar').onclick = () => {
  const data = $('#data').value;

  if (!(escolha.servico && escolha.prof && data && escolha.hora)) {
    return toast('Escolha serviço, profissional, data e horário.');
  }

  if (horariosOcupados().includes(escolha.hora)) {
    return toast('Esse horário acabou de ser ocupado.');
  }

  const servico = buscarServico(escolha.servico);

  me.agendamentos.push({
    id: Date.now(),
    s: escolha.servico,
    p: escolha.prof,
    data: data,
    hora: escolha.hora,
  });

  // 1 ponto a cada R$ 10 gastos
  me.pontos += Math.round(servico.p / 10);
  salvar();

  // Limpa a tela e leva para "Meus horários"
  escolha = { servico: null, prof: null, hora: null };
  $('#data').value = '';
  desenharAgendar();
  toast('Agendamento confirmado! Você ganhou pontos.');
  irPara('meus');
};


/* ==========================================================
   ABA: MEUS HORÁRIOS
   ========================================================== */
function desenharLista() {
  const lista = ordenar(me.agendamentos);

  $('#lista').innerHTML = lista.length
    ? lista.map((a) => {
        const servico = buscarServico(a.s);
        return `
          <div class="ag">
            <div>
              <strong>${servico.n}</strong><br>
              <small>${formatarData(a.data)} às ${a.hora} com ${buscarProf(a.p).n}</small>
            </div>
            <div>
              <span class="preco">${formatarPreco(servico.p)}</span>
              <button class="btn sec peq" data-c="${a.id}">Cancelar</button>
            </div>
          </div>`;
      }).join('')
    : '<p class="vazio">Nenhum horário marcado. Que tal agendar o primeiro?</p>';
}

$('#lista').onclick = (e) => {
  const id = e.target.dataset.c;
  if (!id || !confirm('Cancelar este horário?')) return;

  me.agendamentos = me.agendamentos.filter((a) => a.id != id);
  salvar();
  desenharLista();
  toast('Horário cancelado.');
};


/* ==========================================================
   ABA: SERVIÇOS (catálogo)
   ========================================================== */
$('#catalogo').innerHTML = SERVICOS.map((s) => `
  <div class="item" style="cursor: default">
    <h3>${s.n}</h3>
    <small>${s.d} min</small>
    <div class="preco">${formatarPreco(s.p)}</div>
  </div>`).join('');


/* ==========================================================
   ABA: PERFIL
   ========================================================== */
$('#pn').value = me.nome;
$('#pt').value = me.tel;
$('#pe').value = me.email;
mascaraTel($('#pt'));

$('#fp').onsubmit = (e) => {
  e.preventDefault();

  if ($('#pn').value.trim().length < 3) return toast('Informe seu nome.');

  me.nome = $('#pn').value.trim();
  me.tel = $('#pt').value;
  salvar();
  desenharInicio();
  toast('Perfil atualizado.');
};


/* ==========================================================
   INÍCIO DA PÁGINA
   ========================================================== */
desenharAgendar();
desenharInicio();